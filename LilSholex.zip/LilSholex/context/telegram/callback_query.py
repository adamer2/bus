from contextvars import ContextVar

CALLBACK_QUERY = ContextVar('CALLBACK_QUERY')
QUERY_ID = ContextVar('QUERY_ID')
