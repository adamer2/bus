from contextvars import ContextVar

MESSAGE = ContextVar('MESSAGE')
TEXT = ContextVar('TEXT')
