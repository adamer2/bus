from contextvars import ContextVar

MEME_ID = ContextVar('MEME_ID')
PLAYLIST_ID = ContextVar('PLAYLIST_ID')
REPORT = ContextVar('REPORT')
MEME = ContextVar('MEME')
