from contextvars import ContextVar

CHOSEN_INLINE_RESULT = ContextVar('CHOSEN_INLINE_RESULT')
