from contextvars import ContextVar

INLINE_QUERY = ContextVar('INLINE_QUERY')
QUERY_ID = ContextVar('QUERY_ID')
